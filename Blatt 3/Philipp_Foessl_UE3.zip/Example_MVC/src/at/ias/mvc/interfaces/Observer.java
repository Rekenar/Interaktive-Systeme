package at.ias.mvc.interfaces;

public interface Observer {
	
	public void notifyUpdate();

}
