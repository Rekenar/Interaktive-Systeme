package at.ias.mvc.interfaces;

public interface Observable {
	
	public void addObserver(Observer observer);

}
